-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Apr 18, 2025 alle 18:53
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydatabase`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `monitoraggio_sonno`
--

CREATE TABLE `monitoraggio_sonno` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `data_sonno` date NOT NULL,
  `ora_sonno` time NOT NULL,
  `ora_risveglio` time NOT NULL,
  `durata_sonno` decimal(4,2) NOT NULL,
  `qualita_sonno` int(11) NOT NULL,
  `risvegli_notturni` int(11) NOT NULL,
  `note` text DEFAULT NULL,
  `data_registrazione` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `monitoraggio_sonno`
--

INSERT INTO `monitoraggio_sonno` (`id`, `user_id`, `data_sonno`, `ora_sonno`, `ora_risveglio`, `durata_sonno`, `qualita_sonno`, `risvegli_notturni`, `note`, `data_registrazione`) VALUES
(46, 5, '2025-04-10', '22:00:00', '08:00:00', 10.00, 4, 1, '', '2025-04-18 16:39:25'),
(47, 5, '2025-04-11', '23:00:00', '08:00:00', 9.00, 4, 0, '', '2025-04-18 16:40:03'),
(48, 5, '2025-04-12', '00:00:00', '09:00:00', 9.00, 4, 1, '', '2025-04-18 16:41:05'),
(49, 5, '2025-04-13', '23:00:00', '07:00:00', 8.00, 2, 3, 'Sonno leggermente irregolare, forse dettato dall\'esame di domani', '2025-04-18 16:43:14'),
(50, 5, '2025-04-14', '22:00:00', '12:00:00', 14.00, 5, 0, '', '2025-04-18 16:43:39'),
(51, 5, '2025-04-15', '23:00:00', '10:00:00', 11.00, 4, 1, '', '2025-04-18 16:44:11'),
(52, 5, '2025-04-16', '23:00:00', '10:00:00', 11.00, 4, 0, 'Dormito profondamente, ero molto stanco dopo l\'allenamento di ieri ', '2025-04-18 16:48:20'),
(53, 5, '2025-04-17', '04:00:00', '12:00:00', 8.00, 3, 0, 'Tornato molto tardi a casa dopo una serata', '2025-04-18 16:49:47'),
(54, 5, '2025-04-18', '23:00:00', '10:00:00', 11.00, 4, 1, '', '2025-04-18 16:50:06'),
(55, 7, '2025-04-17', '22:00:00', '08:00:00', 10.00, 5, 0, '', '2025-04-18 16:51:43'),
(56, 4, '2025-04-17', '22:00:00', '05:00:00', 7.00, 2, 4, '', '2025-04-18 16:52:36');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `monitoraggio_sonno`
--
ALTER TABLE `monitoraggio_sonno`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `monitoraggio_sonno`
--
ALTER TABLE `monitoraggio_sonno`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `monitoraggio_sonno`
--
ALTER TABLE `monitoraggio_sonno`
  ADD CONSTRAINT `monitoraggio_sonno_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `utenti` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
